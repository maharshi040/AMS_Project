export class plane
{
    hangerStatus: string
    ownerContactNumber: number
    ownerEmail: string
    ownerFirstName: string
    ownerId: number
    ownerLastName: string
    planeCapacity: number
    planeId: number
    planeType: string
}