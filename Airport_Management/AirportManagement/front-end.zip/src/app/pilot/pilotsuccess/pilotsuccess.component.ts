import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pilotsuccess',
  templateUrl: './pilotsuccess.component.html',
  styleUrls: ['./pilotsuccess.component.css']
})
export class PilotsuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
