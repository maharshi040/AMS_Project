import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-flip-flop-footer',
  templateUrl: './flip-flop-footer.component.html',
  styleUrls: ['./flip-flop-footer.component.css']
})
export class FlipFlopFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
