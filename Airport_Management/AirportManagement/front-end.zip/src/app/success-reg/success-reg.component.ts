import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-success-reg',
  templateUrl: './success-reg.component.html',
  styleUrls: ['./success-reg.component.css']
})
export class SuccessRegComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
