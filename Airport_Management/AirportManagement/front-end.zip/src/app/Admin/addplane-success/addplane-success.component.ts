import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addplane-success',
  templateUrl: './addplane-success.component.html',
  styleUrls: ['./addplane-success.component.css']
})
export class AddplaneSuccessComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
